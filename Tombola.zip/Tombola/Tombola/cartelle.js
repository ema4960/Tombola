smorfiaNapoletana=[
    "L’Italia",
    "‘A Piccerella – La bambina",
    "‘A Jatta – La gatta",
    "‘O puorco – Il maiale",
    "‘A Mano – La mano",
    "Chella ca guarda ‘nterra - Quella che guarda verso terra",
    "‘O Vase – Il Vaso",
    "A’ Madonna – La Madonna",
    "‘A Figliata – La figliolanza",
    "‘E Fasule – I fagioli",
    "‘E Suricille – I topi",
    "‘O Surdate – Il soldato",
    "Sant’Antonio – Sant’Antonio",
    "‘O ‘Mbriaco – L’ubriaco",
    "‘O Guaglione – Il ragazzo",
    "‘O Culo – Il culo",
    "‘A Disgrazzia – La sfortuna",
    "‘O ‘Sanghe – Il sangue",
    "‘A Resata – La risata",
    "‘A Festa – La festa",
    "‘A Femmena annura – La donna nuda",
    "‘O Pazzo – Il pazzo",
    "‘O Scemo – lo scemo",
    "‘E Gguardie – Le guardie",
    "Natal’ – Natale",
    "Nanninella – Anna",
    "‘O Cantero – L’orinale",
    "‘E Zzizze – Le tette",
    "‘O Pate d”e Ccriature – Il padre dei bimbi",
    "‘E Ppalle d”o Tenente – Le palle del Tenente",
    "‘O Padrone ‘e Casa – Il padrone dell’abitazione",
    "‘O Capitone – Il capitone",
    "L’Anne ‘e Cristo – Gli anni di Cristo",
    "‘A Capa – La testa",
    "L’Aucelluzz – L’uccello",
    "‘E Ccastagnelle – Le nacchere",
    "‘O Monaco – Il monaco",
    "‘E Mmazzate – Le bastonate",
    "‘A Funa n’Ganna – La corda al collo",
    "‘A Paposcia – L’ernia",
    "‘O Curtiello – Il coltello",
    "‘O Cafè – Il Caffè",
    "Onna pereta fore ‘O barcone – Donna al balcone",
    "‘E Ccancelle – Le carceri",
    "‘O Vino bbuono – Il buon vino",
    "‘E Denare – I soldi",
    "‘O Muorto – Il morto",
    "‘O Muorto che pparla - Il morto che parla",
    "‘O Piezzo ‘e Carne – La carne",
    "‘O Ppane – Il pane", //50
    "‘O Ciardino – Il giardino",
    "‘A Mamma – La mamma",
    "‘O Viecchio – Il vecchio",
    "‘O Cappiello – Il cappello",
    "‘A Museca – La musica",
    "‘A Caruta – La caduta",
    "‘O Scartellato – Il gobbo",
    "‘O Paccotto – Il cartoccio",
    "‘E Pile – I peli",
    "Se Lamenta – Si lamenta",
    "‘O Cacciatore – Il cacciatore",
    "‘O Muorto acciso – Il morto ammazzato",
    "‘A Sposa – La sposa",
    "‘A Sciammeria – La marsina",
    "‘O Chianto – Il pianto",
    "‘E ddoie Zetelle – Le due zitelle",
    "‘O Totaro int”a Chitarra – Il totano nella chitarra",
    "‘A Zuppa cotta – La minestra cotta",
    "Sott’e ‘Ncoppa – Sottosopra",
    "‘O Palazzo – Il palazzo",
    "L’Ommo ‘e Merda – Essere riprovevole",
    "A Maraviglia – Lo stupore",
    "‘O Spitale – L’ospedale",
    "‘A Rotta – La grotta",
    "Pullecenella – Pulcinella",
    "‘A Funtana – La fontana",
    "‘E Riavulille – I diavoli",
    "‘A bella Figliola – La prostituta",
    "‘O Mariuolo – Il ladro",
    "‘A Vocca – La bocca",
    "‘E Sciure – I fiori",
    "‘A Tavula ‘mbandita – La tavola imbandita",
    "‘O Maletiempo – Il maltempo",
    "‘A Cchiesa – La chiesa",
    "‘Ll Aneme ‘o Priatorio – Le anime del Purgatorio",
    "‘A Puteca – Il negozio",
    "‘E Perucchie – I pidocchi",
    "‘E Casecavalle – I caciocavalli",
    "‘A Vecchia – La vecchia",
    "‘A Paura – La paura",
]

card1=[
    [4,19,30,54,70],
    [10,26,46,60,80],
    [1,20,48,68,84]
];

card2=[
    [13,33,53,67,82],
    [3,21,40,61,79],
    [16,38,57,72,81]
];

card3=[
    [6,25,47,73,85],
    [17,37,55,63,83],
    [8,27,42,69,88]
];

card4=[
    [12,32,52,66,90],
    [9,24,45,75,87],
    [15,34,51,64,78]
];

card5=[
    [2,23,39,44,71],
    [11,35,56,62,86],
    [5,28,41,59,76]
];

card6=[
    [14,31,49,58,74],
    [7,22,43,65,89],
    [18,29,36,50,77]
];

card7=[
    [6,31,53,74,86],
    [18,22,45,68,88],
    [8,16,36,57,71]
];

card8=[
    [17,38,44,54,84],
    [29,47,60,78,80],
    [1,21,48,69,76]
];

card9=[
    [9,20,40,52,73],
    [19,34,43,61,87],
    [25,37,56,75,83]
];

card10=[
    [4,26,58,65,89],
    [7,23,49,59,72],
    [11,39,51,67,85]
];

cards=[card1,card2,card3,card4,card5,card6,card7,card8,card9,card10];





