# Tombola
tpsi project tombola

tombola 37,5% 0.375
cinquina 25% 0.25
quaterna 16.7% 0.167
terno 12.5% 0.125
ambo 8.3% 0.083